/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.SQLException; 


public class h2connect { 
    protected static Connection initializeDatabase() 
        throws SQLException, ClassNotFoundException 
    {
    String dbDriver = "org.h2.Driver";   
  String dbURL = "jdbc:h2:tcp://localhost/~/test/employee";  
     
    String dbUsername = "sa"; 
    String dbPassword = ""; 
     
        Class.forName(dbDriver); 
        Connection con = DriverManager.getConnection(dbURL,
                                                     dbUsername,  
                                                     dbPassword); 
        return con; 
    } 
} 

  
  

